public class States {   
       
    private int x;
    private int y;
    private double utility;
    private int reward;
    private char utilityFunction;

    // non-zero based representation of x,y coor of state in 3x3 grid
    public States(int x, int y) {
        this.x = -1;
        this.y = -1;
        this.utility = 0.0;
        this.reward = -1;
        this.utilityFunction = ' ';
        setX(x);
        setY(y);
    }
    
    /**
     * @return the reward
     */
    public int getReward() {
        return reward;
    }

    /**
     * @param reward the reward to set
     */
    public void setReward(int reward) {
        this.reward = reward;
    }
    
    /**
     * @return the utility
     */
    public double getUtility() {
        return utility;
    }

    /**
     * @param utility the utility to set
     */
    public void setUtility(double utility) {
        this.utility = utility;
    }
    
    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }
    
    /**
     * @return the utilityFunction
     */
    public char getUtilityFunction() {
        return utilityFunction;
    }

    /**
     * @param utilityFunction the utilityFunction to set
     */
    public void setUtilityFunction(char utilityFunction) {
        this.utilityFunction = utilityFunction;
    }
    
     
}
