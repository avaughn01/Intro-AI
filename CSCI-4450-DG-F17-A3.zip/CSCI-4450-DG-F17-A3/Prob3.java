import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class Prob3 {

    public static void main(String[] args) {
        // call constructor
        new Prob3();
    }

    // takes an r value from user and user determined value/policy iteration
    // for mdp, and outputs the policy at each state
    public Prob3() {

        Scanner input = new Scanner(System.in);
        int r = 0;              // user defined r value
        int choice = 0;         // 1 for value iter, 2 for policy iteration  

        // go until user stops
        do {
            // create the states 3x3 grid, non-zeor x,y coor.
            List<States> states = new ArrayList<States>();
            for (int x = 0; x < 3; x++) {
                for (int y = 0; y < 3; y++) {
                    states.add(new States(x + 1, y + 1));
                }
            }
            // get the r and which policy iteration will be used
            r = getR();
            choice = getChoice();

            // set rewards for each state
            for (int i = 0; i < states.size(); i++) {
                // r case
                if (states.get(i).getX() == 1 && states.get(i).getY() == 3) {
                    states.get(i).setReward(r);
                } // terminal state
                else if (states.get(i).getX() == 3 && states.get(i).getY() == 3) {
                    states.get(i).setReward(10);
                } // everything else
                else {
                    states.get(i).setReward(-1);
                }
            }

            // create the actions
            char[] movements = {'u', 'd', 'l', 'r'};
            List<Action> actions = new ArrayList<Action>();
            for (int i = 0; i < movements.length; i++) {
                actions.add(new Action(movements[i]));
            }

            // call value/policy
            if (choice == 1) {
                mdpValue(states, actions, r);

            } else if (choice == 2) {
                mdpPolicy(states, actions, r);
            }
        } while (choice != 3);
    }

    // returns a utility for each state
    public Map<States, Double> mdpValue(List<States> states, List<Action> actions, int r) {
        char bestAction = ' ';      // stores best action
        //double utility = 0.0;
        //double newUtility = 0.0;
        double change = 0.0;        // delta
        double minChange = 0.0;
        double maxAction = 0.0;
        double tempAction = 0.0;
        double discount = 0.50;     // gamma

        // compute the min amount of change allowed
        // in this case epsilon is 10^-3
        double epsilon = Math.pow(10.0, -3.0);
        minChange = epsilon * (1.0 - 0.50) / 0.50;

        // U and Uprime
        Map<States, Double> utility = new HashMap<States, Double>();
        Map<States, Double> newUtility = new HashMap<States, Double>();
        // create the utility
        for (int i = 0; i < states.size(); i++) {
            utility.put(states.get(i), new Double(0.0));
            newUtility.put(states.get(i), new Double(0.0));
        }

        do {

            // update utility and reset change
            utility.putAll(newUtility);
            change = 0.0;

            // go over every state
            for (int i = 0; i < states.size(); i++) {
                // if in last state set maxAction to larger number
                if (i == states.size() - 1) {
                    maxAction = 0.0;
                } else {
                    maxAction = -100.0;
                }
                // go over all the actions checking their utility for every state
                for (int j = 0; j < actions.size(); j++) {
                    tempAction = 0.0;
                    for (States newState : states) {
                        tempAction += transitionProb(states.get(i), actions.get(j), newState) * utility.get(newState);
                    }
                    // if found a better action update it
                    if (tempAction > maxAction) {
                        maxAction = tempAction;
                        bestAction = actions.get(j).getAction();
                        states.get(i).setUtilityFunction(bestAction);
                    }
                } // end for actions.size()

                // set the states new utility
                newUtility.put(states.get(i), states.get(i).getReward() + discount * maxAction);
                // calculate the difference between the old utility and new utility
                double diff = Math.abs(newUtility.get(states.get(i)) - utility.get(states.get(i)));
                // update delta
                if (diff > change) {
                    change = diff;
                }

            } //end for states.size()

        } while (change > minChange);

        double[] policy = new double[states.size()];
        System.out.println("\nPolicy table calculated:");
        for (int i = 0; i < states.size(); i++) {
            policy[i] = utility.get(states.get(i));
            System.out.println("State: " + states.get(i).getX() + "," + states.get(i).getY() + ": " + policy[i] + " " + states.get(i).getUtilityFunction());
        }
        System.out.println();
        
        return utility;

    }

    // returns a policy of what to do for each state
    public Map<States, Action> mdpPolicy(List<States> states, List<Action> actions, int r) {
        Map<States, Double> utility = new HashMap<States, Double>();
        Map<States, Double> newUtility = new HashMap<States, Double>();
        Map<States, Action> pi = new HashMap<States, Action>();
        boolean unchanged = true;
        Random rand = new Random();
        double discount = 0.50;     // gamma
        double actionMax = 0.0;
        double piValue = 0.0;       // stores utility of that action
        double tempAction = 0.0;

        // set the initial utility
        for (int i = 0; i < states.size(); i++) {
            utility.put(states.get(i), new Double(0.0));
            pi.put(states.get(i), actions.get(rand.nextInt(actions.size())));
        }

        do {
            // set the utility to what would happen if current policy were implemented
            for (int i = 0; i < states.size(); i++) {
                List<States> nextStates = new ArrayList<States>();
                // stores utility of that state
                double u = 0.0;
                // grab the states neighbors and update the utility
                nextStates = nextStates(states.get(i), pi.get(states.get(i)));
                for (int j = 0; j < nextStates.size(); j++) {
                    newUtility.put(nextStates.get(j), new Double(0.0));
                    // P(s) * U(s`)
                    u += (transitionProb(states.get(i), pi.get(states.get(i)), nextStates.get(j)) * newUtility.get(nextStates.get(j)));
                    // set the states utility based on current policy from state
                    utility.put(states.get(i), states.get(i).getReward() + discount * u);

                }
            }
            unchanged = true;

            for (int i = 0; i < states.size(); i++) {
                actionMax = -100.0;
                piValue = 0.0;

                // grab the current action
                Action bestAction = pi.get(states.get(i));
                for (int j = 0; j < actions.size(); j++) {
                    tempAction = 0.0;
                    // get value of current action
                    for (States nextState : states) {
                        tempAction += transitionProb(states.get(i), actions.get(j), nextState) * utility.get(nextState);
                    }
                    // check for better actions
                    if (tempAction > actionMax) {
                        actionMax = tempAction;
                        bestAction = actions.get(j);
                    }
                    // if the current action is the action of that state
                    // update the value of that policy's action
                    if (actions.get(j) == pi.get(states.get(i))) {
                        piValue = tempAction;
                    }
                }
                // if value of best action is greater than the value 
                // of current action, update policy for that state
                if (actionMax > piValue) {
                    pi.put(states.get(i), bestAction);
                    unchanged = false;
                }
            }

        } while (!unchanged);

        System.out.println("\nPolicy table calculated:");
        for (int i = 0; i < pi.size(); i++) {
            System.out.printf("%d,%d: %s\n", states.get(i).getX(), states.get(i).getY(), pi.get(states.get(i)).getAction());
        }
        System.out.println();

        return pi;
    }

    // sets reward for top left corner (1,3)
    public int getR() {
        Scanner input = new Scanner(System.in);
        int r = 0;

        System.out.print("Enter value for r (100, -3, 0, 3): ");
        r = input.nextInt();
        while (r != 100 && r != -3 && r != 0 && r != 3) {
            System.out.print("Enter value for r (100, -3, 0, 3): ");
            r = input.nextInt();
        }

        return r;
    }

    // returns user choice of value/policy
    public int getChoice() {
        Scanner input = new Scanner(System.in);
        int choice = 0;

        do {
            System.out.print("Enter 1 for Value Iteration, 2 for Policy Iteration, 3 to Exit: <1 or 2 or 3>: ");
            choice = input.nextInt();
        } while (choice != 1 && choice != 2 && choice != 3);

        return choice;
    }

    // returns a list of possible states based on current state and action taken
    // wall collision will add the current state to list of next states
    public List<States> nextStates(States state, Action action) {
        List<States> nextStates = new ArrayList<States>();
        int changeX = 0;
        int changeY = 0;

        // get a direction based on possible directions
        if (action.getAction() == 'u') {
            changeY = 1;
        }
        if (action.getAction() == 'd') {
            changeY = -1;
        }
        if (action.getAction() == 'l') {
            changeX = -1;
        }
        if (action.getAction() == 'r') {
            changeX = 1;
        }

        // ensure we stay in bounds
        if (changeX + state.getX() > 3 || changeX + state.getX() < 1) {
            changeX = 0;
        }
        if (changeY + state.getY() > 3 || changeY + state.getY() < 1) {
            changeY = 0;
        }
        // add the next state (note this might be the state itself)
        nextStates.add(new States(changeX + state.getX(), changeY + state.getY()));

        // get the next possible directions, 1 or 2 more, and these may be
        // the current state itself
        for (int i = 0; i < action.getUncertain().size(); i++) {
            if (action.getUncertain().get(i) == 'u') {
                changeY = 1;
            }
            if (action.getUncertain().get(i) == 'd') {
                changeY = -1;
            }
            if (action.getUncertain().get(i) == 'l') {
                changeX = -1;
            }
            if (action.getUncertain().get(i) == 'r') {
                changeX = 1;
            }
            // ensure we stay in bounds
            if (changeX + state.getX() > 3 || changeX + state.getX() < 1) {
                changeX = 0;
            }
            if (changeY + state.getY() > 3 || changeY + state.getY() < 1) {
                changeY = 0;
            }
            nextStates.add(new States(changeX + state.getX(), changeY + state.getY()));
        }

        return nextStates;
    }

    // calculates the probability of going to the next state
    // .8 for certain .1 for uncertain wall collision adds to prob
    public double transitionProb(States state, Action action, States nextState) {
        double prob = 0.0;
        char move = ' ';
        int diffX = 0;      // diff of x1 - x2
        int diffY = 0;      // diff of y1 - y2
        int changeX = 0;    // used to switch char value
        int changeY = 0;    // used to switch char value
        double add = 0.0;
        // ensure we are doing only 1 move
        int diffSum = Math.abs(state.getX() - nextState.getX()) + Math.abs(state.getY() - nextState.getY());
        if (diffSum > 1) {
            return 0.0;
        }
        // get the differenfce we are going in
        diffX = nextState.getX() - state.getX();
        diffY = nextState.getY() - state.getY();

        // go over all the actions, in future i will rewrite my action class so
        // this is not hard coded to 3
        for (int i = 0; i < 3; i++) {
            // get certain/uncertain move
            if (i == 0) {
                add = 0.80;
                move = action.getAction();
            } else {
                add = 0.10;
                move = action.getUncertain().get(i - 1);
            }
            // get the value of that move
            if (move == 'u') {
                changeY = 1;
                changeX = 0;
            }
            if (move == 'd') {
                changeY = -1;
                changeX = 0;
            }
            if (move == 'r') {
                changeX = 1;
                changeY = 0;
            }
            if (move == 'l') {
                changeX = -1;
                changeY = 0;
            }
            // handle wall collision
            if (state.getX() + changeX > 3 || state.getX() + changeX < 1) {
                changeX = 0;
            }
            if (state.getY() + changeY > 3 || state.getY() + changeY < 1) {
                changeY = 0;
            }
            // add them to prob
            if (diffX == changeX && changeY == diffY) {
                prob += add;
            }

        }

        return prob;
    }
}
