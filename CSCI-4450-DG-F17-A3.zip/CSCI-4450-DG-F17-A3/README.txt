Problem 2:
    Ensure hw3-crime_data.csv is in same directory as Prob2.java
    also this direcotry contains the q2.txt if you would like to have the      
    program generate a q2.txt from its current run then uncomment lines 
    100-107. If the lines are uncommented, then the generated q2.txt is placed 
    in the same directory as the Prob2.java file.
        COMPILE: 
            javac Prob2.java
        RUN: 
            java Prob2

Problem 3:
    the transitionProb() function is not working correctly
        COMPILE:
            javac Prob3.java
        RUN:
            java Prob3
