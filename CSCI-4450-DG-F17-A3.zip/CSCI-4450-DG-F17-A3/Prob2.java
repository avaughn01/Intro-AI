import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Prob2 {

    // this just gets the file and passes it to constructor
    public static void main(String[] args) throws FileNotFoundException {
       
        File f = getFile();

        new Prob2(f);
    }

    public Prob2(File f) throws FileNotFoundException {
        // scanner to read the file, and list to store the data
        Scanner input = new Scanner(f);
        List<KState> states = new ArrayList<KState>();

        // get rid of first line
        String parse = input.nextLine();

        // get the data
        while (input.hasNext()) {
            parse = input.nextLine();
            String[] data = parse.split(",");
            states.add(new KState(data[0], Integer.parseInt(data[1]),
                    Double.parseDouble(data[2]),
                    Double.parseDouble(data[3]),
                    Double.parseDouble(data[4]),
                    Double.parseDouble(data[5])));
        }
        // go over Kmeans with different number of clusters
        for (int k = 2; k <= 10; k++) {
            KState[] centroids = new KState[k];
            kMeans(states, centroids, k);
        }
    }

    // this implements the kmeans algorithm with different values for k
    public void kMeans(List<KState> states, KState[] centroids, int k) {
        int iterations = 0;
        double distortion = 0.0;
        int bestCluster = 1;
        boolean changes = true;
        double minDist = 0.0;
        double tempDist = 0.0;
        Random rand = new Random();

        // assign some random centroids
        for (int i = 0; i < k; i++) {
            int temp = rand.nextInt(states.size());
            //String name, int crimeCluster, double murder, double assault, double urbanPop, double rape
            centroids[i] = new KState("Centroid", i + 1, states.get(temp).getMurder(), states.get(temp).getAssault(), states.get(temp).getUrbanPop(), states.get(temp).getRape());
        }

        // assign states to their various clusters until the grouping does not change
        while (changes) {
            minDist = 0.0;
            tempDist = 0.0;
            changes = false;
            for (int i = 0; i < states.size(); i++) {
                bestCluster = 1;
                minDist = distance(states.get(i), centroids[0]);
                // check for smallest distance from state to centroid
                for (int j = 1; j < centroids.length; j++) {
                    tempDist = distance(states.get(i), centroids[j]);
                    if (tempDist < minDist) {
                        minDist = tempDist;
                        bestCluster = j + 1;
                    }
                }
                // if we have a better cluster assign that state to it
                if (states.get(i).getCrimeCluster() != bestCluster) {
                    states.get(i).setCrimeCluster(bestCluster);
                    changes = true;
                }
            }
            // if changes were made get a new group of centroids
            if (changes) {
                centroids = newCentroids(states, centroids);
            }
            iterations++;
        }
        
        distortion = distortion(states, centroids);
        //System.out.println("For K-value: " + k);
        //System.out.println("Iterations: " + iterations);
        //System.out.printf("Distortion: %.02f\n", distortion);
        //System.out.println();
        //printClusters(states, centroids);
       
        /* 
        try {
            writeFile(k, iterations, distortion);
        } catch (IOException ex) {
            Logger.getLogger(Prob2.class.getName()).log(Level.SEVERE, null, ex);
        }
        */        

    }
    
    // this creates a file with the iterations and distortion for each 
    // K-value
    public void writeFile(int k, int iterations, double distortion) throws IOException {
    FileWriter fileWriter = new FileWriter("q2.txt", true);
    PrintWriter printWriter = new PrintWriter(fileWriter);
    String append = String.format("K-value: %d\nIterations: %d\nDistortion: %.02f\n--------------------\n", k, iterations, distortion);
        printWriter.append(append);
    printWriter.close();
}
    
    // returns the distortion of the k-clusters
    // sum of square distance of each state from its closest centroid
    public double distortion(List<KState> states, KState[] centroids) {
        double distortion = 0.0;
        
        for (int j = 0; j < states.size(); j++) {
            distortion += Math.pow(distance(states.get(j), centroids[states.get(j).getCrimeCluster() - 1]), 2);
        }
        
        return distortion;
    }
    
    public void printClusters(List<KState> states, KState[] centroids) {
        
        for (int i = 0; i < centroids.length; i++) {
            int cluster = i+1;
            System.out.print("Cluster " + cluster + ": ");
            for (int j = 0; j < states.size(); j++) {
                if (states.get(j).getCrimeCluster() == i+1) {
                    System.out.print("'" + states.get(j).getName() + "' ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    // sqrt of the sum of the squares for each of its data entries
    // uses euclidean distance formula
    public double distance(KState state, KState centroid) {
        double dist = 0.0;

        dist = Math.sqrt(Math.pow(state.getMurder() - centroid.getMurder(), 2.0)
                + Math.pow(state.getAssault() - centroid.getAssault(), 2.0)
                + Math.pow(state.getUrbanPop() - centroid.getUrbanPop(), 2.0)
                + Math.pow(state.getRape() - centroid.getRape(), 2.0));

        return dist;
    }

    // assign new values for the centroids murder, assault, urbanpop, and rape
    public KState[] newCentroids(List<KState> states, KState[] centroids) {
        KState[] newCentroids = new KState[centroids.length];

        double murder = 0.0;
        double assault = 0.0;
        double urbanPop = 0.0;
        double rape = 0.0;
        double numMembers = 0.0;
        int cluster = 0;    
        
        for (int i = 0; i < centroids.length; i++) {
            cluster = i + 1;
            numMembers = 0.0;
            murder = 0.0;
            assault = 0.0;
            urbanPop = 0.0;
            rape = 0.0;
            for (int j = 0; j < states.size(); j++) {
                if (states.get(j).getCrimeCluster() == cluster) {
                    murder += states.get(j).getMurder();
                    assault += states.get(j).getAssault();
                    urbanPop += states.get(j).getUrbanPop();
                    rape += states.get(j).getRape();
                    numMembers++;
                }
            }
            //String name, int crimeCluster, double murder, double assault, double urbanPop, double rape
            if (numMembers != 0) {
            newCentroids[i] = new KState("Centroid", cluster, murder / numMembers, assault / numMembers, urbanPop / numMembers, rape / numMembers);
            }
            else {
                newCentroids[i] = new KState("Centroid", cluster, centroids[i].getMurder(), centroids[i].getAssault(), centroids[i].getUrbanPop(), centroids[i].getRape());
            }
        }

        return newCentroids;
    }

    public static File getFile() {
        File f = new File("hw3-crime_data.csv");

        return f;
    }

}
