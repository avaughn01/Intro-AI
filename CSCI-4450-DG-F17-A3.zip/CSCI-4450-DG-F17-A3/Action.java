
import java.util.ArrayList;
import java.util.List;

public class Action {

    private char action;                    // action being taken
    private List<Character> uncertain;      // possible uncertain actions

    // action being take
    public Action(char action) {
        // initially set action to space
        this.uncertain = new ArrayList<Character>();

        // add the list of uncertain actions based on the current action being taken
        setAction(action);
        if (this.action == 'u') {
            this.uncertain.add('l');
            this.uncertain.add('r');
        }
        if (this.action == 'd') {
            this.uncertain.add('r');
            this.uncertain.add('l');
        }
        if (this.action == 'l') {
            this.uncertain.add('u');
            this.uncertain.add('d');
        }
        if (this.action == 'r') {
            this.uncertain.add('u');
            this.uncertain.add('d');
        }
    }

    /**
     * @return the action
     */
    public char getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(char action) {
        this.action = action;
    }
    
    /**
     * @return the uncertain
     */
    public List<Character> getUncertain() {
        return uncertain;
    }

    /**
     * @param uncertain the uncertain to set
     */
    public void setUncertain(List<Character> uncertain) {
        this.uncertain = uncertain;
    }
}
