public class KState {       
    
    private String name;        // Name of state
    private int crimeCluster;   // Its current cluster
    private double murder;      // Murder from csv
    private double assault;     // Assault from csv
    private double urbanPop;    // Urban Population from csv
    private double rape;        // Rape from csv
    private double distance;    // Not currently implemented

    public KState(String name, int crimeCluster, double murder, double assault, double urbanPop, double rape) {
        
        setName(name);
        setCrimeCluster(crimeCluster);
        setMurder(murder);
        setAssault(assault);
        setUrbanPop(urbanPop);
        setRape(rape);
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the crimeCluster
     */
    public int getCrimeCluster() {
        return crimeCluster;
    }

    /**
     * @param crimeCluster the crimeCluster to set
     */
    public void setCrimeCluster(int crimeCluster) {
        this.crimeCluster = crimeCluster;
    }

    /**
     * @return the murder
     */
    public double getMurder() {
        return murder;
    }

    /**
     * @param murder the murder to set
     */
    public void setMurder(double murder) {
        this.murder = murder;
    }

    /**
     * @return the assault
     */
    public double getAssault() {
        return assault;
    }

    /**
     * @param assault the assault to set
     */
    public void setAssault(double assault) {
        this.assault = assault;
    }

    /**
     * @return the urbanPop
     */
    public double getUrbanPop() {
        return urbanPop;
    }

    /**
     * @param urbanPop the urbanPop to set
     */
    public void setUrbanPop(double urbanPop) {
        this.urbanPop = urbanPop;
    }

    /**
     * @return the rape
     */
    public double getRape() {
        return rape;
    }

    /**
     * @param rape the rape to set
     */
    public void setRape(double rape) {
        this.rape = rape;
    }
    
    /**
     * @return the distance
     */
    public double getDistance() {
        return distance;
    }

    /**
     * @param distance the distance to set
     */
    public void setDistance(double distance) {
        this.distance = distance;
    }
    
    // How the class is printed out
    @Override
    public String toString() {
        String print = "";
        
        // String name, int crimeCluster, double murder, int assault, int ubarnPop, double rape
        print = getName() + " " + Integer.toString(getCrimeCluster()) + " " + Double.toString(getMurder()) + " " + Double.toString(getAssault()) + " "
                + Double.toString(getUrbanPop()) + " " + Double.toString(getRape());
        
        return print;
    }

}
